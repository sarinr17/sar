<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjam extends CI_Controller {

  public function __construct()
  {
      parent::__construct();
      $this->load->library('form_validation');
      $this->load->model('Model_peminjam');
      $this->load->model('Model_barang');
      if (!$this->session->userdata('username')) {
          redirect('auth');
      }
  }

  public function index()
  {
      $data['title'] = 'Peminjam';
      if ($this->input->post('submit')) {
          $data['keyword'] = $this->input->post('keyword');
      } else {
          $data['keyword'] = null;
      }

      $data['peminjam'] = $this->Model_peminjam->getAllPeminjam($data['keyword']);

      $this->load->view('templates/header.php', $data);
      $this->load->view('peminjam/index.php', $data);
      $this->load->view('templates/footer.php');
  }

  public function tambah()
  {
      $data['barang'] = $this->Model_barang->getAllBarang();
      $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
      $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
      $this->form_validation->set_rules('no_hp', 'No hp', 'trim|required|numeric');
      $this->form_validation->set_rules('keperluan', 'Keperluan', 'trim|required');


      if($this->form_validation->run() == false ) {
          $data['title'] = 'Tambah Peminjam';

          $this->load->view('templates/header.php', $data);
          $this->load->view('peminjam/tambah.php', $data);
          $this->load->view('templates/footer.php');
      } else {
          $this->Model_peminjam->Tambahpeminjam();
          redirect('peminjam');
      }

  }

  public function ubah($id)
  {
      $data['peminjam'] = $this->Model_peminjam->getPeminjamById($id);
      $data['barang'] = $this->Model_barang->getAllBarang();
      $this->form_validation->set_rules('nama', 'Nama', 'trim|required|');
      $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required|');
      $this->form_validation->set_rules('no_hp', 'No hp', 'trim|required|numeric');
      $this->form_validation->set_rules('keperluan', 'Keperluan', 'trim|required|');

      if($this->form_validation->run() == false ) {
          $data['title'] = 'Ubah Peminjam';

          $this->load->view('templates/header.php', $data);
          $this->load->view('peminjam/ubah.php', $data);
          $this->load->view('templates/footer.php');
      } else {
          $this->Model_peminjam->Ubahpeminjam();
          $old_image = $data['peminjam']['foto'];
          unlink(FCPATH . 'assets/foto/' . $old_image);
          $this->session->set_flashdata('flash', 'Diubahkan');
          redirect('peminjam');
      }

  }

  public function detail($id)
  {
      $data['peminjam'] = $this->Model_peminjam->getPeminjamById($id);

      $data['title'] = 'Detail Peminjam';
      $this->load->view('templates/header.php', $data);
      $this->load->view('Peminjam/detail.php', $data);
      $this->load->view('templates/footer.php');
      

  }

  public function hapus($id)
  {
      $data['peminjam'] = $this->Model_peminjam->getPeminjamById($id);
      $old_image = $data['peminjam']['foto'];
      unlink(FCPATH . 'assets/foto/' . $old_image);
      $this->Model_peminjam->hapusPeminjam($id);
      $this->session->set_flashdata('flash', 'Dihapus');
      redirect('peminjam');
  }
}