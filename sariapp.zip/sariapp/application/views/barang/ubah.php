<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Barang</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $barang['id']; ?>">
            <label for="barang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="barang" name="barang" value="<?= $barang['barang']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('barang'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>