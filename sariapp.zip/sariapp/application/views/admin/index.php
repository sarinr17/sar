<div class="container">
  
</div>
<style>
    body {
        background-image:url("https://media.istockphoto.com/id/926588306/id/vektor/ikon-set-peralatan-kantor.jpg?s=1024x1024&w=is&k=20&c=u__AAnk0octp2C0166wlzGEXVshhBX8DQ7W2HbnRxcY=");
    </style>